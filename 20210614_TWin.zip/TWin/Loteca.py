
import sys
import numpy as np
import csv
import datetime

from itertools import combinations

jogos = list()
jogosF = list()

def gerar_jogos(numeros, qSorteio):

    for jogo in combinations(numeros, qSorteio ):
        jogos.append(sorted(jogo)) #numeros que serão combinados e o tamanho do grupo
    
def fechamento (qtdAcertos):
    
    jogosF.append(jogos[0])
    i=0

    for jogo in jogos:
        adicionarJogo = "S"
        i=i+1
        for jogoAux in jogosF:
            qtdNRepetidos = len(np.intersect1d(np.array(jogo),np.array(jogoAux)))  
            if qtdNRepetidos>=qtdAcertos:
                adicionarJogo="N"
                break
        if adicionarJogo=="S":
            jogosF.append(jogo)
        

def simulacao(sorteio,qSorteio):

    resultados = [0 for n in range( qSorteio+1 )]

    for jogo in jogosF:
        resultado = len(np.intersect1d(np.array(jogo),np.array(sorteio)))
        if resultado == 5:
            print(jogo," - " ,sorteio," -> ",resultado)
        resultados[resultado]=resultados[resultado]+1

    print(resultados)

if __name__ == '__main__':   
    
    begin_time = datetime.datetime.now()
    
    qTotalNumeros = 42
    qSorteio = 14
    qtdAcertos = 11
    vlrJogo = 2

    numeros = np.sort([1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42])
    sorteio = [2,5,8,11,14,17,20,23,26,29,32,35,38,41]    


    print(len(numeros))
    gerar_jogos(numeros,qSorteio)
    fechamento(qtdAcertos)
    print(len(jogos))
    print(len(jogosF))
    print("Valor Combo: ", len(jogosF)*vlrJogo)

    simulacao(sorteio,qSorteio)


    # print("Todos as combinaçoes possiveis: ")
    # for i in jogos:
    #      print(*i, sep=";")
        
    # print("Jogos gerados pelo fechamento: ")
    # for i in jogosF:
    #    print(*i, sep=";")
    
    #Create File    
    file = open('facilF.csv', 'w+', newline = '')    
    with file:
        write = csv.writer(file)
        write.writerows(jogosF)
 

    end_time = datetime.datetime.now()
    print(end_time - begin_time)