import csv
import datetime
import numpy as np

from itertools import combinations

jogos = list()
jogosF = list()
sorteioAnterior = []

def gerar_jogos(numeros, qSorteio):

    for jogo in combinations(numeros, qSorteio ):
        jogos.append(sorted(jogo)) #numeros que serão combinados e o tamanho do grupo
 
    np.random.shuffle(jogos)

def fechamento (qtdAcertos):
    
    jogosF.append(jogos[0])
    i=0

    for jogo in jogos:
        adicionarJogo = "S"
        i=i+1
        # if i%2!=0:
        #     continue
        # else:
        for jogoAux in jogosF:
            qtdNRepetidos = len(np.intersect1d(np.array(jogo),np.array(jogoAux)))  
            if qtdNRepetidos>=qtdAcertos:
                adicionarJogo="N"
                break

        if adicionarJogo=="S":
            if filtrar(np.array(jogo)):
                jogosF.append(sorted(jogo))

def filtrar(jogo):

    #Ideias de Filtros:
        #Numeros de concursos anteriores

    addJogo=True
    previousN=-1
    qtdImpar=0
    qtdPar=0
    qtdNSequence=0
    
    linha1 = 0
    linha2 = 0
    linha3 = 0
    linha4 = 0
    linha5 = 0

    
    for i in jogo:

        #Verifica quantidade de impar e par
        if (i%2)==0:
            qtdPar=qtdPar+1
        else:
            qtdImpar=qtdImpar+1
    
        #Qtde numeros por grupo de sequencias
        if i>=1 and i<=5:
            linha1 =linha1+1 #1-5
        elif (i>=6 and i<=10):
            linha2 =linha2+1 #6-10
        elif (i>=11 and i<=15):
            linha3 =linha3+1 #11-15
        elif (i>=16 and i<=20):
            linha4 =linha4+1 #16-20
        elif (i>=21 and i<=25):
            linha5 =linha5+1 #21-25

    #Quantidade de numeros em sequencia
        if (i-previousN)==1:
            qtdNSequence=qtdNSequence+1    
        else:
            qtdNSequence=0
        previousN=i

        #Quantidade de numeros em sequencia    
        if qtdNSequence > 5:
            addJogo=False
            break
        
   
    if addJogo==True:

        #Verifica quantidade de impar e par
        if not((qtdPar >= 6 and qtdPar <= 9) & (qtdImpar >= 6 and qtdImpar <= 9)):
            #print('Par:  ', qtdPar, 'Impart:  ', qtdImpar)
            addJogo=False

        #Soma dos numeros deve estar entre 166 e 222
        if not(np.sum(jogo) >= 166 & np.sum(jogo) <=222):
            addJogo = False

        #Verifica a quantidade de numeros repetidos em comparação com o concurso anterior
        qtdNJogoAnterior = len(np.intersect1d(np.array(sorteioAnterior),np.array(jogo)))
        if not(qtdNJogoAnterior>6 & qtdNJogoAnterior<12):
            addJogo=False

        #Qtde numeros por grupo de sequencias
        qtdMinimaPorLinha=2
        if (linha1<=qtdMinimaPorLinha or 
            linha2<=qtdMinimaPorLinha or
            linha3<=qtdMinimaPorLinha or
            linha4<=qtdMinimaPorLinha or
            linha5<=qtdMinimaPorLinha):
            addJogo = False
            
   
    return addJogo

def simulacao(sorteio):

    resultados = [0 for n in range( qSorteio+1 )]

    for jogo in jogosF:
        resultado = len(np.intersect1d(np.array(jogo),np.array(sorteio)))
        if resultado == qSorteio:
            print(jogo," - " ,sorteio," -> ",resultado)

        if resultado >= 14:
            print(jogo," - " ,sorteio," -> ",resultado)

        resultados[resultado]=resultados[resultado]+1


    print("Total de resultados: ")

    r=0
    for i in resultados:
        if i>0:
            print("Quantidade de acertos com", r," numeros: ",i)
        r=r+1
    #print(resultados)

if __name__ == '__main__':   
    
    begin_time = datetime.datetime.now()

    qTotalNumeros = 25
    qSorteio = 15
    qtdAcertos = 12
    vlrJogo = 2.5

    
    #sorteioAnterior = [2,6,11,12,14,15,16,17,18,19,21,22,23,24,25] #Concurso:2249
    #sorteio         = [4,5,6,10,12,13,14,18,19,20,21,22,23,24,25] #Concurso:2250
    #sorteioAnterior = [4,5,6,10,12,13,14,18,19,20,21,22,23,24,25] #Concurso:2250
    #sorteio         = [2,4,5,7,9,12,13,14,15,18,19,21,22,23,24] #Concurso:2251
    sorteioAnterior = [2,3,5,6,7,8,12,14,15,16,18,19,20,23,25] #Concurso:2251
    sorteio         = [1,2,4,5,6,9,10,11,14,17,18,19,22,24,25] #Concurso:New -- 9
    


    #numeros = [1,2,4,5,6,8,9,11,12,14,17,18,20,22,23,24,25] #17 numeros
    #numeros = [1,2,4,5,6,7,21,9,10,12,14,16,18,19,20,22,24,25] #18 numeros
    #numeros = [1,2,4,5,6,7,8,9,10,12,14,16,18,19,20,22,23,24,25] #19 numeros
    #numeros = [1,2,3,4,5,6,7,8,9,10,11,12,14,16,18,20,22,23,24,25] #20 numeros
    #numeros = [1,2,4,5,6,7,8,9,10,11,12,13,14,16,18,20,21,22,24,25] #21 numeros
    #numeros = [1,2,4,5,6,7,8,9,10,11,12,13,14,16,18,19,20,21,22,24,25] #21 numeros
    numeros =  np.sort([1,2,3,4,5,6,8,9,10,11,12,13,14,15, 17,18,19,20,22,23,24,25]) #22 numeros
    #numeros = [2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,24,25] #23 numeros 6'01'' -- 3'30''
    #numeros = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25] #25 numeros    

    print(len(numeros))
    gerar_jogos(numeros,qSorteio)
    print(len(jogos))
    fechamento(qtdAcertos)
    print(len(jogosF))
    print("Valor Combo: ", len(jogosF)*vlrJogo)
    simulacao(sorteio)

    # print("Todos as combinaçoes possiveis: ")
    # for i in jogos:
    #      print(*i, sep=";")
        
    # print("Jogos gerados pelo fechamento: ")
    # for i in jogosF:
    #    print(*i, sep=";")
    
    #Create File    
    file = open('facilF.csv', 'w+', newline = '')

    with file:
        write = csv.writer(file)
        write.writerows(jogosF)


    end_time = datetime.datetime.now()
    print(end_time - begin_time)