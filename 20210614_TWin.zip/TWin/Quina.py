
import sys
import numpy as np
import csv
import datetime

from itertools import combinations

jogos = list()
jogosF = list()

def gerar_jogos(numeros, qSorteio):

    for jogo in combinations(numeros, qSorteio ):
        jogos.append(sorted(jogo)) #numeros que serão combinados e o tamanho do grupo
    
def fechamento (qtdAcertos):
    
    jogosF.append(jogos[0])
    i=0

    for jogo in jogos:
        adicionarJogo = "S"
        i=i+1
        for jogoAux in jogosF:
            qtdNRepetidos = len(np.intersect1d(np.array(jogo),np.array(jogoAux)))  
            if qtdNRepetidos>=qtdAcertos:
                adicionarJogo="N"
                break
        if adicionarJogo=="S":
            jogosF.append(jogo)
        

def simulacao(sorteio,qSorteio):

    resultados = [0 for n in range( qSorteio+1 )]

    for jogo in jogosF:
        resultado = len(np.intersect1d(np.array(jogo),np.array(sorteio)))
        if resultado == 5:
            print(jogo," - " ,sorteio," -> ",resultado)
        resultados[resultado]=resultados[resultado]+1

    print(resultados)

if __name__ == '__main__':   
    
    begin_time = datetime.datetime.now()
    
    qTotalNumeros = 80
    qSorteio = 5
    qtdAcertos = 2
    vlrJogo = 2

    #numeros = [1,2,3,4,5,6,7] #7 numeros
    #numeros = [4,5,12,24,67,30,8] #7 numeros
    #numeros = [5,12,24,67,30,8,23,54,11,19,28] #11
    #numeros = np.sort([5,12,67,30,8,54,11,19,32,31,44,47,49,78,76]) #15 numeros
    numeros = np.sort([50,5,12,24,67,30,8,23,54,11,19,28,32,31,44,42,47,49,78,76]) #20 numeros
    #numeros = [20,24,32,35,45,51,57,60,63,72] #10 numeros
    #numeros = [20,24,32,35,45,51,57,60,63,72,1,2,3,4,5] #15 numeros    
    #numeros = [4,6,8,9,10,11,12,14,19,20,24,27,28,31,32,35,36,38,43,46,47,48,52,55,56,56,63,67,71,72,75] #30 numeros
    


    print(len(numeros))
    gerar_jogos(numeros,qSorteio)
    fechamento(qtdAcertos)
    print(len(jogos))
    print(len(jogosF))
    print("Valor Combo: ", len(jogosF)*vlrJogo)

    #sorteio = [30,24,67,11,12] # Quadra
    sorteio = [12,8,31,49,76] # Quina
    #sorteio = [28,19,11,54,12] # [7, 16, 10, 1, 1]
    #sorteio = [23,54,11,19,28] # [7, 16, 10, 1, 1]
    #sorteio = [20,24,60,63,72] 
    #sorteio = [4,22,32,64,74]
    simulacao(sorteio,qSorteio)


    # print("Todos as combinaçoes possiveis: ")
    # for i in jogos:
    #      print(*i, sep=";")
        
    # print("Jogos gerados pelo fechamento: ")
    # for i in jogosF:
    #    print(*i, sep=";")
    
    #Create File    
    file = open('facilF.csv', 'w+', newline = '')    
    with file:
        write = csv.writer(file)
        write.writerows(jogosF)
 

    end_time = datetime.datetime.now()
    print(end_time - begin_time)