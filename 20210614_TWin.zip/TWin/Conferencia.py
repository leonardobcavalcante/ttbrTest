
import numpy as np
import csv

#if __name__ == '__main__':  

resultadosFacil = list()
fechamentoFacil = list()

with open('resultado_Facil_ate_20210607_onlynumbers.csv', 'r', encoding='utf-8') as f:
    csv_reader = csv.reader(f, delimiter=';')
    csv_reader.__next__()
    for row in csv_reader:
        resultadosFacil.append(row)

with open('facilF.csv', 'r', encoding='utf-8') as f:
    csv_reader = csv.reader(f, delimiter=',')
    csv_reader.__next__()
    for row in csv_reader:
        fechamentoFacil.append(row)

resultados  = [0 for n in range( 15+1 )]
resultTotal = [0 for n in range( 15+1 )]

for ff in fechamentoFacil:
    resultados = [0 for n in range( 15+1 )]
    for rf in resultadosFacil:
        resultado = len(np.intersect1d(np.array(ff),np.array(rf)))
        resultados[resultado]=resultados[resultado]+1
        resultTotal[resultado]=resultTotal[resultado]+1
    #print(resultados)
print(resultTotal)


# print("Total de resultados: ")

# r=0
# for i in resultados:
#     print("Quantidade de acertos com", r," numeros: ",i)
#     r=r+1
#print(resultados)
