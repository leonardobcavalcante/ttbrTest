
import sys
import numpy as np
import csv
import datetime

from itertools import combinations

jogos = list()
jogosF = list()

def gerar_jogos(numeros, qSorteio):

    for jogo in combinations(numeros, qSorteio ):
        jogos.append(sorted(jogo)) #numeros que serão combinados e o tamanho do grupo
    
def fechamento (qtdAcertos):
    
    jogosF.append(jogos[0])
    i=0

    for jogo in jogos:
        adicionarJogo = "S"
        i=i+1
        for jogoAux in jogosF:
            qtdNRepetidos = len(np.intersect1d(np.array(jogo),np.array(jogoAux)))  
            if qtdNRepetidos>=qtdAcertos:
                adicionarJogo="N"
                break
        if adicionarJogo=="S":
            jogosF.append(jogo)
        

def simulacao(sorteio,qSorteio):

    resultados = [0 for n in range( qSorteio+1 )]

    for jogo in jogosF:
        resultado = len(np.intersect1d(np.array(jogo),np.array(sorteio)))
        if resultado == 5:
            print(jogo," - " ,sorteio," -> ",resultado)
        resultados[resultado]=resultados[resultado]+1

    print(resultados)

if __name__ == '__main__':   
    
    begin_time = datetime.datetime.now()
    print(begin_time)
    
    qTotalNumeros = 100
    qSorteio = 20
    qtdAcertos = 16
    vlrJogo = 2

    sorteio = [3,4,11,13,21,23,27,30,35,37,51,56,63,65,67,76,81,84,93,94]
    numeros = [3,4,6,7,8,9,10,11,12,13,14,15,17,18,19,21,22,23,25,27,28,29,30,31,32,34,35,36,37,38,39,41,43,44,45,46,47,49,50,51,53,54,55,56,57,58,59,60,61,62,63,65,67,69,72,73,74,75,76,78,79,80,81,82,83,84,86,87,88,89,90,91,92,94,95,96,97,98,99,100,]  # 80
  
    print(len(numeros))
    gerar_jogos(numeros,qSorteio)
    fechamento(qtdAcertos)
    print(len(jogos))
    print(len(jogosF))
    print("Valor Combo: ", len(jogosF)*vlrJogo)

    simulacao(sorteio,qSorteio)


    # print("Todos as combinaçoes possiveis: ")
    # for i in jogos:
    #      print(*i, sep=";")
        
    # print("Jogos gerados pelo fechamento: ")
    # for i in jogosF:
    #    print(*i, sep=";")
    
    #Create File    
    file = open('LM.csv', 'w+', newline = '')    
    with file:
        write = csv.writer(file)
        write.writerows(jogosF)
 

    end_time = datetime.datetime.now()
    print(end_time - begin_time)